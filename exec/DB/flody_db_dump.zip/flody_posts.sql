CREATE DATABASE  IF NOT EXISTS `flody` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `flody`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: i7B101.p.ssafy.io    Database: flody
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `pos_no` bigint NOT NULL AUTO_INCREMENT,
  `comment_cnt` int NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `hashtag` varchar(255) DEFAULT NULL,
  `like_cnt` int NOT NULL,
  `post_date` datetime(6) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cat_no` bigint DEFAULT NULL,
  `cov_no` bigint DEFAULT NULL,
  `use_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_no`),
  KEY `fk_posts_useemail_users_email` (`use_email`),
  KEY `fk_posts_catno_categories_catno` (`cat_no`),
  KEY `fk_posts_covno_coverages_covno` (`cov_no`),
  CONSTRAINT `fk_posts_catno_categories_catno` FOREIGN KEY (`cat_no`) REFERENCES `categories` (`cat_no`),
  CONSTRAINT `fk_posts_covno_coverages_covno` FOREIGN KEY (`cov_no`) REFERENCES `coverages` (`cov_no`),
  CONSTRAINT `fk_posts_useemail_users_email` FOREIGN KEY (`use_email`) REFERENCES `users` (`email`),
  CONSTRAINT `FKhmoxc39magsyx83hn8jl0eg9f` FOREIGN KEY (`use_email`) REFERENCES `users` (`email`) ON DELETE CASCADE,
  CONSTRAINT `FKl8o49q4gff4ycjrbrj7m6nhyt` FOREIGN KEY (`cov_no`) REFERENCES `coverages` (`cov_no`) ON DELETE CASCADE,
  CONSTRAINT `FKqcf197sbpwppeu6yupkmoflk4` FOREIGN KEY (`cat_no`) REFERENCES `categories` (`cat_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,0,'살려줘',NULL,0,'2022-08-18 05:07:46.978000',NULL,4,1,'jgh1320@korea.ac.kr'),(2,0,'제발',NULL,0,'2022-08-18 05:07:52.071000',NULL,4,1,'jgh1320@korea.ac.kr'),(3,0,'이렇게',NULL,0,'2022-08-18 05:07:56.374000',NULL,4,1,'jgh1320@korea.ac.kr'),(4,0,'부탁할게',NULL,0,'2022-08-18 05:08:01.355000',NULL,4,1,'jgh1320@korea.ac.kr'),(5,0,'ㅠㅠㅠㅠㅠㅠㅠ',NULL,0,'2022-08-18 05:08:14.135000',NULL,4,1,'jgh1320@korea.ac.kr'),(6,0,'나도 지금 당장',NULL,0,'2022-08-18 05:08:21.973000',NULL,4,1,'jgh1320@korea.ac.kr'),(7,0,'잠을 자고 싶단말야',NULL,0,'2022-08-18 05:08:28.620000',NULL,4,1,'jgh1320@korea.ac.kr');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:06:58
