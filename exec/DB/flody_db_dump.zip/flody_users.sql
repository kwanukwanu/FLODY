CREATE DATABASE  IF NOT EXISTS `flody` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `flody`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: i7B101.p.ssafy.io    Database: flody
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `email` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `admin` bit(1) NOT NULL,
  `introduction` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1234@gmail.com','대전 유성구',_binary '\0',NULL,'누구겡','닉네임','$2a$10$FokQN7Ng1DTL3TqgDZixSeklS/niN0TfzOZG3kLwH.THymSOVlZyK','123-412-3412','default01.png'),('admin@ssafy.com','대전연수원',_binary '','관리자입니다','김관리','Flody','$2a$10$zRRPv.3toet9lHMGdcn8.uRNwKEojtLOokYaNtpPXI9S.ghdYI2bO','010-1111-2222','https://placekitten.com/300/400'),('dofl8787@naver.com','SSAFY 대전캠퍼스',_binary '','대전 공통 1반 최고!','김애리','앨앨','$2a$10$ZznSIn5dJe.xHWEf3UO2VeKEST0OfjX4fKBiKic.zLlArG9NwkmWC','010-2912-8780','https://placekitten.com/300/300'),('hi@hi.com','대전 유성구',_binary '\0',NULL,'HI','닉네임','$2a$10$XoFyVYKFx/fsKiy0Tt/HZOPjVQCBWdKDyxZTFDWHbrcIE6clv12K.','010-1234-5678','default01.png'),('jgh1320@korea.ac.kr','대전 유성구',_binary '\0',NULL,'장종환','배고파','$2a$10$P9CHAeQNGyDCWiO7zJ254uD2jy9KO6yHOfrn7F402rXioNZLBsLVu','010-1379-2468','basic profile.jpg'),('kwanukok@gmail.com','SSAFY 대전캠퍼스',_binary '',NULL,'최재현','과누쓰','$2a$10$I4IBdJbWbT/5kJysK7m0ke40LYEl08M.YHQEy9SZ05oL.1bfyLz7S','010-7472-7820','https://placekitten.com/200/100'),('myssafy@ssafy.com','SSAFY 대전캠퍼스',_binary '',NULL,'김관리','관리자','$2a$10$U0923JriZ76mfEVeU6/wMukYTAfktXMN35Wa5HU1SWluITHTSXt9K','010-1234-4567','https://placekitten.com/200/100'),('s@ssafy.com','SSAFY 대전캠퍼스',_binary '',NULL,'김관리','관리자','$2a$10$m6PAL.yX.jZH.MaEbqKZE.8LU0ZM0In9QKoyFk4RRzaZDSHlgdL82','010-1234-4567','https://placekitten.com/300/800'),('ssafy@ssafy.com','SSAFY 대전캠퍼스',_binary '',NULL,'김싸피','개인','$2a$10$M7adsuIMq0eEyUfLSEeMN.WqRcNQrp1a.7W8Gb1MJZ7r.J8UrT.si','010-1234-4567','https://placekitten.com/200/100'),('test01@naver.com','',_binary '','난 김테스트','김테스트','tupdate01','$2a$10$u8QQrzPz7OjrZsZRMkC9Duwn8.z2nDmjfUccj/m2s7vV3TuyrTWxi','','https://placekitten.com/200/100');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:06:52
