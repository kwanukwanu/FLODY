CREATE DATABASE  IF NOT EXISTS `flody` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `flody`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: i7B101.p.ssafy.io    Database: flody
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `m_fields`
--

DROP TABLE IF EXISTS `m_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m_fields` (
  `mf_no` bigint NOT NULL AUTO_INCREMENT,
  `mobligfldcd` varchar(10) NOT NULL,
  `mobligfldnm` varchar(255) NOT NULL,
  PRIMARY KEY (`mf_no`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_fields`
--

LOCK TABLES `m_fields` WRITE;
/*!40000 ALTER TABLE `m_fields` DISABLE KEYS */;
INSERT INTO `m_fields` VALUES (106,'251','안전관리'),(107,'162','기계장비설비.설치'),(108,'141','건축'),(109,'201','전기'),(110,'024','생산관리'),(111,'144','도시.교통'),(112,'171','금속.재료'),(113,'167','금형.공작기계'),(114,'161','기계제작'),(115,'262','에너지.기상'),(116,'142','토목'),(117,'241','농업'),(118,'261','환경'),(119,'252','비파괴검사'),(120,'243','임업'),(121,'202','전자'),(122,'191','섬유'),(123,'244','어업'),(124,'221','식품'),(125,'174','용접'),(126,'211','정보기술'),(127,'082','디자인'),(128,'143','조경'),(129,'164','조선'),(130,'166','자동차'),(131,'163','철도'),(132,'242','축산'),(133,'175','도장.도금'),(134,'165','항공'),(135,'181','화공'),(136,'151','채광'),(137,'232','목재.가구.공예'),(138,'121','이용.미용'),(139,'145','건설배관'),(140,'182','위험물'),(141,'222','제과.제빵'),(142,'131','조리'),(143,'173','단조.주조'),(144,'172','판금.제관.새시'),(145,'192','의복'),(146,'061','보건.의료'),(147,'021','경영'),(148,'122','숙박.여행.오락.스포츠'),(149,'231','인쇄.사진'),(150,'071','사회복지.종교'),(151,'091','운전.운송'),(152,'101','영업.판매'),(153,'146','건설기계운전'),(154,' ',' '),(155,'061-2','보건.의료(국제의료관광코디네이터)'),(156,'083','방송'),(157,'213','통신'),(158,'212','방송.무선'),(159,'152','광해방지'),(160,'031','금융.보험'),(161,'253','의학');
/*!40000 ALTER TABLE `m_fields` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:06:52
