CREATE DATABASE  IF NOT EXISTS `flody` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `flody`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: i7B101.p.ssafy.io    Database: flody
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `g_members`
--

DROP TABLE IF EXISTS `g_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `g_members` (
  `gm_no` bigint NOT NULL AUTO_INCREMENT,
  `gro_no` bigint DEFAULT NULL,
  `gr_no` bigint DEFAULT NULL,
  `use_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`gm_no`),
  KEY `fk_gmembers_useemail_users_email` (`use_email`),
  KEY `fk_gmembers_grono_groups_grono` (`gro_no`),
  KEY `fk_gmembers_grno_groles_grno` (`gr_no`),
  CONSTRAINT `fk_gmembers_grno_groles_grno` FOREIGN KEY (`gr_no`) REFERENCES `g_roles` (`gr_no`),
  CONSTRAINT `fk_gmembers_grono_groups_grono` FOREIGN KEY (`gro_no`) REFERENCES `s_groups` (`gro_no`),
  CONSTRAINT `fk_gmembers_useemail_users_email` FOREIGN KEY (`use_email`) REFERENCES `users` (`email`),
  CONSTRAINT `FKe2mbi3g7l4468ysk3m9i6c1ud` FOREIGN KEY (`use_email`) REFERENCES `users` (`email`) ON DELETE CASCADE,
  CONSTRAINT `FKjvdk1bq09txbgtb4q568d4wm9` FOREIGN KEY (`gr_no`) REFERENCES `g_roles` (`gr_no`) ON DELETE CASCADE,
  CONSTRAINT `FKqtce05gwairudkdite8inlhuw` FOREIGN KEY (`gro_no`) REFERENCES `s_groups` (`gro_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `g_members`
--

LOCK TABLES `g_members` WRITE;
/*!40000 ALTER TABLE `g_members` DISABLE KEYS */;
INSERT INTO `g_members` VALUES (1,9,1,'myssafy@ssafy.com'),(2,10,1,'myssafy@ssafy.com'),(3,11,1,'myssafy@ssafy.com'),(4,12,1,'myssafy@ssafy.com'),(5,13,1,'myssafy@ssafy.com'),(6,14,1,'myssafy@ssafy.com'),(7,16,1,'myssafy@ssafy.com'),(9,17,1,'myssafy@ssafy.com'),(10,18,1,'myssafy@ssafy.com'),(12,20,1,'myssafy@ssafy.com'),(13,21,1,'myssafy@ssafy.com'),(14,22,1,'myssafy@ssafy.com'),(15,23,1,'myssafy@ssafy.com'),(16,24,1,'myssafy@ssafy.com'),(17,25,1,'myssafy@ssafy.com'),(18,26,1,'myssafy@ssafy.com'),(19,27,1,'myssafy@ssafy.com'),(20,28,1,'myssafy@ssafy.com'),(21,29,1,'myssafy@ssafy.com'),(22,30,1,'myssafy@ssafy.com'),(23,31,1,'myssafy@ssafy.com'),(24,32,1,'myssafy@ssafy.com'),(28,36,1,'s@ssafy.com'),(30,38,1,'s@ssafy.com'),(31,39,1,'s@ssafy.com'),(32,40,1,'s@ssafy.com'),(33,41,1,'s@ssafy.com'),(34,42,1,'s@ssafy.com'),(35,43,1,'s@ssafy.com'),(36,44,1,'s@ssafy.com'),(37,45,1,'s@ssafy.com'),(38,46,1,'s@ssafy.com'),(39,47,1,'s@ssafy.com'),(40,48,1,'s@ssafy.com'),(41,49,1,'s@ssafy.com'),(42,50,1,'s@ssafy.com'),(43,50,3,'ssafy@ssafy.com'),(44,51,1,'s@ssafy.com'),(45,51,3,'ssafy@ssafy.com'),(47,52,1,'s@ssafy.com'),(48,52,3,'ssafy@ssafy.com'),(49,53,1,'jgh1320@korea.ac.kr'),(50,54,1,'s@ssafy.com'),(51,54,3,'ssafy@ssafy.com'),(52,55,1,'s@ssafy.com'),(53,55,3,'ssafy@ssafy.com'),(54,56,1,'admin@ssafy.com'),(55,56,3,'s@ssafy.com'),(56,57,1,'s@ssafy.com'),(57,57,3,'ssafy@ssafy.com'),(58,58,1,'s@ssafy.com'),(59,58,3,'ssafy@ssafy.com'),(60,59,1,'s@ssafy.com'),(61,59,3,'ssafy@ssafy.com'),(62,59,3,'admin@ssafy.com'),(63,60,1,'dofl8787@naver.com'),(65,60,3,'test01@naver.com'),(66,61,1,'test01@naver.com'),(67,61,3,'jgh1320@korea.ac.kr'),(68,58,3,'dofl8787@naver.com'),(69,62,1,'admin@ssafy.com'),(70,62,3,'test01@naver.com'),(72,62,3,'dofl8787@naver.com'),(73,63,1,'admin@ssafy.com'),(74,63,3,'dofl8787@naver.com');
/*!40000 ALTER TABLE `g_members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:06:56
